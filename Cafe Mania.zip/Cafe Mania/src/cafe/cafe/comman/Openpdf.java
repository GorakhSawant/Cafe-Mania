
package coffee.cafe.comman;

import javax.swing.JOptionPane;
import java.io.File;


public class Openpdf {
    public static void openById(String id){
        try{
            if((new File("E:\\"+id+".pdf")).exists()) {
            Process p = Runtime
                    .getRuntime()
                    .exec("rundll32 url.dll,FileProtocolHandler E:\\"+id+".pdf");
        }
            else
                JOptionPane.showMessageDialog(null, "File is not Exists");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
   
    
}